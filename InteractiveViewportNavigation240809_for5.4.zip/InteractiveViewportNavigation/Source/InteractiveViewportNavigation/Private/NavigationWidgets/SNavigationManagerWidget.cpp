﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SNavigationManagerWidget.h"

#include "InteractiveNavigationUtils.h"
#include "SDirectionIndicatorWidget.h"
#include "Slate/SlateBrushAsset.h"
#include "Widgets/Layout/SScaleBox.h"
#include "IAssetViewport.h"
#include "InteractiveNavigationSettings.h"
#include "LevelEditor.h"
#include "VectorTypes.h"
//#include "Behaviors/2DViewportBehaviorTargets.h"
//#include "Behaviors/2DViewportBehaviorTargets.h"
#include "EditorGizmos/TransformGizmo.h"

void SNavigationManagerWidget::UpdateDPIScaling(const UInteractiveNavigationSettings* Settings)
{
	//自动获取
	if(Settings->bManualCorrectDeviation == false)
	{
		//只在初始化时设置该缩放倍数, 因为用户几乎不可能在使用引擎途中调整系统DPI,即使调整,重新构造即可. 若要实时判断, 性能消耗浪费
		FDisplayMetrics DisplayMetrics;
		FDisplayMetrics::RebuildDisplayMetrics(DisplayMetrics);

		TArray<FMonitorInfo>& MonitorInfoArray = DisplayMetrics.MonitorInfo;
		if(MonitorInfoArray.Num() == 0) return;
		//只获取屏幕0的DPI, 因为用户几乎不可能设置两块屏幕为不同的DPI, 尽管有这种可能性
		ScaleBasedDPI = (float)MonitorInfoArray[0].DPI / 96.f;
	}
	//手动设置
	else
	{
		switch (Settings->DPI)
		{
		case EDisplayDeviceScaling::DPI_100: ScaleBasedDPI = 1.f;
			break;
		case EDisplayDeviceScaling::DPI_125: ScaleBasedDPI = 1.25f;
			break;
		case EDisplayDeviceScaling::DPI_150: ScaleBasedDPI = 1.5f;
			break;
		case EDisplayDeviceScaling::DPI_175: ScaleBasedDPI = 1.75f;
			break;
		case EDisplayDeviceScaling::DPI_200: ScaleBasedDPI = 2.f;
			break;
		}
	}
	LocalOffsetToCenter = OffsetToCenter * ScaleBasedDPI;
	LocalRange = 100.f * ScaleBasedDPI * ScaleBasedDPI;
}

void SNavigationManagerWidget::Construct(const FArguments& InArgs)
{
	const UInteractiveNavigationSettings* Settings = GetDefault<UInteractiveNavigationSettings>();
	UpdateDPIScaling(Settings);
	if(!OnPostEditChangePropertyDelegateHandle.IsValid())
	{
		OnPostEditChangePropertyDelegateHandle = FNavigationSettingsDelegates::OnPostEditChangeProperty.AddStatic(&SNavigationManagerWidget::UpdateDPIScaling);
	}
	
	USlateBrushAsset* SlateBrushPositive = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SpherePositive"));
	FSlateBrush* BrushPositive = SlateBrushPositive!=nullptr ? &SlateBrushPositive->Brush : new FSlateBrush();
	
	USlateBrushAsset* SlateBrushNegative = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SphereNegative"));
	FSlateBrush* BrushNegative = SlateBrushNegative!=nullptr ? &SlateBrushNegative->Brush : new FSlateBrush();
	
	EditorViewportClient = &FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetFirstActiveViewport()->GetAssetViewportClient();

	AxisSlots.SetNumUninitialized(ElementsNum);
	
	FOverlaySlot* SlotAxisX = MakeNavigationElement(
		BrushPositive,
		FVector(1.f,0.f,0.f),
		DIAxisColorX,
		FString(TEXT("X")),
		ETransformGizmoPartIdentifier::TranslateXAxis,
		true
	);
	AxisSlots[0] = SlotAxisX;
	
	FOverlaySlot* SlotAxisY = MakeNavigationElement(
		BrushPositive,
		FVector(0.f,1.f,0.f),
		DIAxisColorY,
		FString(TEXT("Y")),
		ETransformGizmoPartIdentifier::TranslateYAxis,
		true
	);
	AxisSlots[1] = SlotAxisY;
	
	FOverlaySlot* SlotAxisZ = MakeNavigationElement(
		BrushPositive,
		FVector(0.f,0.f,1.f),
		DIAxisColorZ,
		FString(TEXT("Z")),
		ETransformGizmoPartIdentifier::TranslateZAxis,
		true
	);
	AxisSlots[2] = SlotAxisZ;
	
	FOverlaySlot* SlotAxis_X = MakeNavigationElement(
		BrushNegative,
		FVector(-1.f,0.f,0.f),
		DIAxisColorX,
		FString(TEXT("-X")),
		ETransformGizmoPartIdentifier::RotateXAxis,
		false
	);
	AxisSlots[3] = SlotAxis_X;
	
	FOverlaySlot* SlotAxis_Y = MakeNavigationElement(
		BrushNegative,
		FVector(0.f,-1.f,0.f),
		DIAxisColorY,
		FString(TEXT("-Y")),
		ETransformGizmoPartIdentifier::RotateYAxis,
		false
	);
	AxisSlots[4] = SlotAxis_Y;
	
	FOverlaySlot* SlotAxis_Z = MakeNavigationElement(
		BrushNegative,
		FVector(0.f,0.f,-1.f),
		DIAxisColorZ,
		FString(TEXT("-Z")),
		ETransformGizmoPartIdentifier::RotateZAxis,
		false
	);
	AxisSlots[5] = SlotAxis_Z;
	
	//以0元素初始化, 避免出现未初始化的值
	SortDepth.SetNumZeroed(ElementsNum);

	//初始化tick计数
	ResetTickTimes();
	
	SetCanTick(true);
}

int32 SNavigationManagerWidget::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId,const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	static ELevelViewportType LastTimeLevelViewportType = LVT_None;
	const ELevelViewportType CurrentViewportType = EditorViewportClient->GetViewportType();
	//static FRotator LastFixRotator = FRotator::ZeroRotator;
	
	ViewStateIsInChanging = true;
	//在type不变的前提下, 考虑所有不需要更新旋转的情况, 改变type当帧更新
	if(LastTimeLevelViewportType == CurrentViewportType)
	{
		//当前不是透视视图, 旋转不更新 
		if(CurrentViewportType != LVT_Perspective)
		{
			ViewStateIsInChanging = false;
		}
		//当前并非需要修复旋转, 旋转值等于已记录的, 不需要更新旋转, 该判断的消耗比更新旋转更大, 但涉及到更新排序(排序消耗并不高), 故判断
		else if(!UpdateNavigationNeedFixState() && ViewRotation.Equals(EditorViewportClient->GetViewRotation()))
		{
			ViewStateIsInChanging = false;
		}
		//在修复旋转以及未按下LeftMouseButton时, 旋转一定是不变的, 不需要再判断旋转值. 无论旋转值保持为alt之前的, 还是进入之后修复, 都会是正确的
		else if(UpdateNavigationNeedFixState() && !EditorViewportClient->Viewport->KeyState(EKeys::LeftMouseButton))
		{
			ViewStateIsInChanging = false;
		}
	}
	
	
	if(ViewStateIsInChanging)
	{
		//透视视图情况
		if(CurrentViewportType == LVT_Perspective)
		{
			ViewRotation = EditorViewportClient->GetViewRotation();
			if(UpdateNavigationNeedFixState())
			{
				ViewRotation.Yaw *= -1.f;
				ViewRotation.Yaw += 90.f;
			}
		}     

		//正交视图情况
		else if(CurrentViewportType == LVT_OrthoXY)         ViewRotation = LookFromZ;      //Top
		else if(CurrentViewportType == LVT_OrthoNegativeXY) ViewRotation = LookToZ;        //Bottom
		else if(CurrentViewportType == LVT_OrthoNegativeXZ) ViewRotation = LookToY;        //Left
		else if(CurrentViewportType == LVT_OrthoXZ)         ViewRotation = LookFromY;      //Right
		else if(CurrentViewportType == LVT_OrthoNegativeYZ) ViewRotation = LookFromX;      //Front
		else if(CurrentViewportType == LVT_OrthoYZ)         ViewRotation = LookToX;        //Back
		
		LastTimeLevelViewportType = CurrentViewportType;
	}
	
	//遍历子项, 调用子项的OnPaint(), 
	return SOverlay::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle,bParentEnabled);
}

void SNavigationManagerWidget::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//第1帧, 此时排序开始有效,强制排序一次,无论视口是否变化.
	if(TickTimes == 1)
	{
		UpdateDepthSort();
	}
	//第2帧, 开始tick检查视口是否变化, 若变化, 执行排序,并更新视口信息
	if(TickTimes > 1 && ViewStateIsInChanging)
	{
		UpdateDepthSort();
	}

	//每帧计数加1, 在第1帧将计数加到2后就不再执行计数
	if(TickTimes < 2) { ++TickTimes; }
	
	SOverlay::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

bool SNavigationManagerWidget::UpdateNavigationNeedFixState() const
{
	static bool bNeedFix = false;

	const FViewport* ClientViewport = EditorViewportClient->Viewport;
	
	const bool bMouseButtonDown =
		ClientViewport->KeyState(EKeys::LeftMouseButton) ||
		ClientViewport->KeyState(EKeys::RightMouseButton)||
		ClientViewport->KeyState(EKeys::MiddleMouseButton);
	
	const bool bAltPressed = EditorViewportClient->IsAltPressed();

	//代替记录鼠标移动, 记录鼠标移动不够灵敏, 最小为1像素单位, 容易延迟
	const bool bCameraMoving = EditorViewportClient->IsMovingCamera();
	
	//三者并列时, 需要修复
	if(bCameraMoving && bMouseButtonDown && bAltPressed)
	{
		bNeedFix = true;
	}

	//仅在松开alt时, 复原
	if(bNeedFix == true)
	{
		if(bAltPressed == false)
		{
			bNeedFix = false;
		}
	}
	
	return bNeedFix;
}

void SNavigationManagerWidget::UpdateDepthSort()
{
	//按深度排序
	for (int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i] = TPair<float,FOverlaySlot*>(NavigationElements[i]->GetLoaclDepth(),AxisSlots[i]);
	}
	
	SortDepth.Sort();

	for(int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i].Value->SetZOrder(ElementsNum-i);
	}
}

::SOverlay::FOverlaySlot* SNavigationManagerWidget::MakeNavigationElement(FSlateBrush* InBrush, const FVector& AxisDirection, const FColor AxisColor, const FString& ShowText, ETransformGizmoPartIdentifier PartIdentifier, const bool IsPositive)
{
	TSharedPtr<SDirectionIndicatorWidget> NavigationElement;
	FOverlaySlot* SlotAxisZ = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
			//DirectionIndicator.ToSharedRef()
			SAssignNew(NavigationElement,SDirectionIndicatorWidget)
			.SetBrush(InBrush)
			//.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(AxisDirection * AxisLength)
			.SetAxisColor(FLinearColor::FromPow22Color(AxisColor))
			.SetAxisText(ShowText)
			.SetPartIdentifier(static_cast<uint32>(PartIdentifier))
			.SetIsPositive(IsPositive)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElement);
	return SlotAxisZ;
}

FInputRayHit SNavigationManagerWidget::IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos)
{
	FInputRayHit Hit;
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			//todo:这里需要检查所有, 找到最前的
			const FInputRayHit NewHit = Current->IsHit(MouseScreenPos);
			if ((!Hit.bHit || NewHit.HitDepth < Hit.HitDepth) && NewHit.bHit)
			{
				Hit = NewHit;
			}
		}
	}
	
	return Hit;
}

void SNavigationManagerWidget::UpdateHoverState(bool bHovering, uint32 PartIdentifier)
{
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			Current->UpdateHoverState(bHovering,PartIdentifier);
		}
	}
}